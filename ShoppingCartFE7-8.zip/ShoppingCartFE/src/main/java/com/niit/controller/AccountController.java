package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nnit.entities.*;


@Controller
public class AccountController {
	private Object message;

	@RequestMapping("/login")
	public ModelAndView accountcontroller()
	{
		return new ModelAndView("welcome","message" , message);
	}

	@RequestMapping( value="/login", method = RequestMethod.GET)
	public String login(ModelMap mm){
		mm.put("account", new Account());
		return "login";
	}

	@RequestMapping( value="/login", method = RequestMethod.POST)
	public String login(@ModelAttribute(value="account") Account account ,ModelMap mm){
		if(account.getUsername().equals("niit")&& account.getPassword().equals("niit"))
		{
			mm.put("username", account.getUsername());
			return "home";
		}
		else
		{
			mm.put("message",  "invalid");
		    return "error";     
		    
		}
	
	}
	
	@RequestMapping( value="/register", method = RequestMethod.GET)
	public String register(ModelMap mm){
		mm.put("account", new Account());
		return "register";
	}
	
	
}
	
	