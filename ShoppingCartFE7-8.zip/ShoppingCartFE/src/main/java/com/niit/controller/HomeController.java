package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.nnit.entities.Account;

@Controller 
public class HomeController {
	@RequestMapping("/aboutus")
	 public String showAboutUs()
	 {
		 return "aboutus";
		 
	 }
	@RequestMapping("/contactus")
	public String showContactUs()
	{
		return "contactus";
	}
	@RequestMapping("/What's New")
	public String showWhatsNew()
	{
		return "whats New";
	}
	
	
 
	
}
