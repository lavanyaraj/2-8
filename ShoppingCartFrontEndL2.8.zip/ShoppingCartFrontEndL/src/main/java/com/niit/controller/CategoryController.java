package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.ShoppingCart.dao.CategoryDAO;
import com.niit.ShoppingCart.model.Category;

@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	
	
@RequestMapping(value="/categories",method=RequestMethod.GET)
public String listCategories(Model model){
	model.addAttribute("category",category);
model.addAttribute("categoryList", this.categoryDAO.list());
return "category";

}
@RequestMapping(value="/category/add",method=RequestMethod.POST)
public String addCategory(@ModelAttribute("category") Category category){
	categoryDAO.saveOrUpdate("category",category);

return "category";
}
}